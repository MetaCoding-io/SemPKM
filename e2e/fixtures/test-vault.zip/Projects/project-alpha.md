---
type: project
status: active
tags:
  - planning
---
# Project Alpha

This is the main project. See [[meeting-notes]] for details.
