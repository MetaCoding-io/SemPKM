---
title: Weekly Sync
tags:
  - meetings
  - planning
---
# Weekly Sync

Discussion about #important topics.
See [[project-alpha]] for context.
